# skyscanner-virtual-internship
A Dropwizard microservice is created to assist users in car rentals and hotels.
